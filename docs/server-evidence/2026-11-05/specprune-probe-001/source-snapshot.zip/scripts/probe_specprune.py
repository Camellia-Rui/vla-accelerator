"""Experimental SpecPrune real-input lifecycle probe; not deployment admission."""
import argparse
import copy
import json
from pathlib import Path
import sys
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('workspace','checkpoint','observation','output'): p.add_argument('--'+n,required=True)
 args=p.parse_args()
 out=Path(args.output); out.mkdir(parents=True,exist_ok=False)
 from core.runtime_env import runtime_environment
 import os
 os.environ.update(runtime_environment(out/'cache'))
 sys.path.insert(0,args.workspace)
 report={'passed':False,'quality_decision':'INCONCLUSIVE','closed_loop_tested':False}
 adapter=None
 try:
  import torch
  import numpy as np
  from experiments.robot import openvla_utils as vu
  from methods.specprune.accelerator import AcceleratorConfig,SpecPruneAccelerator
  from methods.vla_pruner.runtime import load_observation
  from methods.vla_pruner.evaluation import difference,trace,actions_array
  cfg=AcceleratorConfig(pretrained_checkpoint=args.checkpoint,unnorm_key='libero_object_no_noops',token_prune=False,dynamic_prune=False,action_adapter=False)
  # Explicit local class loader bypasses upstream get_vla's checkpoint sync.
  config=vu.OpenVLAConfig.from_pretrained(args.checkpoint,local_files_only=True)
  model=vu.OpenVLAForActionPrediction.from_pretrained(args.checkpoint,config=config,torch_dtype=torch.bfloat16,low_cpu_mem_usage=True,local_files_only=True,attn_implementation='eager').to('cuda:0').eval()
  model.vision_backbone.set_num_images_in_input(2)
  model.norm_stats=json.loads((Path(args.checkpoint)/'dataset_statistics.json').read_text())
  processor=vu.get_processor(cfg)
  head=vu.get_action_head(cfg,model.llm_dim).eval()
  proprio=vu.get_proprio_projector(cfg,model.llm_dim,8).eval()
  obs=load_observation(args.observation)
  obs['prev_images']=[obs['full_image'].copy(),obs['wrist_image'].copy()]
  original=SpecPruneAccelerator(model,processor,head,proprio,config=cfg)
  def query(acc):
   acc.start_episode()
   with torch.inference_mode(): return actions_array(acc._query_model(copy.deepcopy(obs),obs['instruction'])[0])
  native,lengths=trace(model,lambda:query(original))
  report.update(native_actions=native.tolist(),native_lengths=lengths)
  modules=dict(model.named_modules()); parameters=dict(model.named_parameters())
  samples={n:v.detach().flatten()[:64].cpu().clone() for n,v in parameters.items()}
  adapter=SpecPruneAccelerator.install(model,processor,head,proprio,config=copy.deepcopy(cfg))
  control,control_lengths=trace(model,lambda:query(adapter))
  report['control']=difference(native,control)
  if not report['control']['matches']: raise RuntimeError('Retain-all control differs from native')
  adapter.cfg.token_prune=True; adapter.cfg.dynamic_prune=True
  actions,pruned_lengths=trace(model,lambda:query(adapter))
  report.update(accelerated_actions=actions.tolist(),action_difference=difference(native,actions),control_lengths=control_lengths,pruned_lengths=pruned_lengths)
  report['mechanism_observed']=any(y<x for k,v in control_lengths.items() for x,y in zip(v,pruned_lengths.get(k,[])))
  adapter.detach(); adapter=None
  report['restored']=difference(native,query(original))
  report['modules_restored']=dict(model.named_modules()).keys()==modules.keys() and all(dict(model.named_modules())[n] is m for n,m in modules.items())
  report['parameters_preserved']=all(dict(model.named_parameters())[n] is v and torch.equal(v.detach().flatten()[:64].cpu(),samples[n]) for n,v in parameters.items())
  report['passed']=all((report['restored']['matches'],report['modules_restored'],report['parameters_preserved'],report['mechanism_observed']))
 except Exception as exc:
  report['error']=str(exc); report['traceback']=traceback.format_exc(); print(report['traceback'])
 finally:
  if adapter is not None: adapter.detach()
  (out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
 return 0 if report['passed'] else 2

if __name__=='__main__': raise SystemExit(main())
