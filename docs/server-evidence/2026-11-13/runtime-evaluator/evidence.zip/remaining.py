import json,os,subprocess,time
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');os.chdir(root)
(root/'remaining.pid').write_text(str(os.getpid()))
while not (root/'process-003.json').exists():time.sleep(3)
base=dict(schema_version=1,gpu=1,output_root=str(root),observation_dirs=[])
routes=[
 ('lightvla_spatial','/home/wxy/daisy_work/lightvla_clean','/home/wxy/daisy_work/lightvla_clean/checkpoints/lightvla_spatial_official','/home/wxy/miniconda3/envs/daisy_openvla/bin/python'),
 ('specprune_object','/home/wxy/cloris_work/SpecPrune-VLA/openvla-oft','/home/wxy/cloris_work/models/openvla-7b-oft-finetuned-libero-object','/home/wxy/cloris_work/env/bin/python'),
 ('fastv_oft_spatial','/home/wxy/daisy_work/openvla-oft','/home/wxy/daisy_work/checkpoints/openvla-7b-oft-finetuned-libero-spatial','/data4/wxy/midterm-oft-first-use/env/bin/python'),
 ('fastv_openvla_spatial','/home/wxy/daisy_work/openvla-fastv-code','/home/wxy/daisy_work/checkpoints/openvla-7b-finetuned-libero-spatial','/data2/wxy/VLA-Adapter/conda_envs/openvla-fastv/bin/python')]
for profile,workspace,checkpoint,python in routes:
 p=dict(base,profile=profile,workspace=workspace,checkpoint=checkpoint,python=python)
 if profile=='specprune_object':p['observation_dirs']=['/home/wxy/Rui_work/toolbox-native-check/capture-001']
 if profile=='fastv_oft_spatial':p['cublas_dir']='/data4/wxy/midterm-oft-first-use/runtime-cublas/nvidia/cublas/lib'
 project=root/(profile+'.json');project.write_text(json.dumps(p,indent=2))
 cmd=[python,'-u','-B','-m','core','select','--project',str(project),'--output',profile+'-001']
 if profile!='fastv_openvla_spatial':cmd+=['--tasks','0']
 env=os.environ.copy();env.update(PYTHONPATH='/data4/wxy/midterm-oft-first-use/src/LIBERO',LIBERO_CONFIG_PATH='/data4/wxy/midterm-oft-first-use/libero-config',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TF_NUM_INTEROP_THREADS='2',TF_NUM_INTRAOP_THREADS='4')
 (root/(profile+'-command.json')).write_text(json.dumps(cmd))
 with (root/(profile+'.log')).open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (root/(profile+'-process.json')).write_text(json.dumps({'exit_code':result.returncode}))
