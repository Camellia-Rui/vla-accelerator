# 自动评估报告

执行状态：FINISHED
样本门槛：NOT_SPECIFIED
选择：未选择

样本满足门槛不代表统计无损或部署验收通过。未提供门槛时仅报告证据。

|模式|成功回合|平均查询 ms|平均策略总耗时 ms|平均回合墙钟 s|查询/策略/墙钟加速比|
|---|---:|---:|---:|---:|---|
|baseline|1/1|133.06|1330.60|3.476|1.000× / 1.000× / 1.000×|
|packaged|1/1|77.04|770.42|2.948|1.727× / 1.727× / 1.179×|

Model-query wrapper, excluding simulator steps; per-episode sum uses all queries

选择器各候选的排除原因：
- baseline: 未排除；未给门槛时不作达标判断
- lightvla: 未排除；未给门槛时不作达标判断

原始报告：/home/wxy/Rui_work/live-evaluator-20261113/lightvla_spatial-004/measurement/report.json
SHA256：2d4caa3a5741fb9c63afc9ffd7b253b62236f212ea1408fadbb998795893740d
