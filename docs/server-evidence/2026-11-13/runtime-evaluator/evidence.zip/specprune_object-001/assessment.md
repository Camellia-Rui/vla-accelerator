# 自动评估报告

执行状态：FINISHED
样本门槛：NOT_SPECIFIED
选择：未选择

样本满足门槛不代表统计无损或部署验收通过。未提供门槛时仅报告证据。

|模式|成功回合|平均查询 ms|平均策略总耗时 ms|平均回合墙钟 s|查询/策略/墙钟加速比|
|---|---:|---:|---:|---:|---|
|baseline|1/1|185.85|3738.25|21.714|1.000× / 1.000× / 1.000×|
|specprune|1/1|119.95|2299.93|16.575|1.549× / 1.625× / 1.310×|

SpecPrune: query includes preprocessing/controller; strategy total includes queue-only calls

选择器各候选的排除原因：
- baseline: 未排除；未给门槛时不作达标判断
- specprune: 未排除；未给门槛时不作达标判断

原始报告：/home/wxy/Rui_work/live-evaluator-20261113/specprune_object-001/measurement/report.json
SHA256：2f2502a00fabb2657b46d2a827c102564e8cc2ffc7e86c07f9ce29462cdfad7f
