# 自动评估报告

执行状态：FINISHED
样本门槛：NOT_SPECIFIED
选择：未选择

样本满足门槛不代表统计无损或部署验收通过。未提供门槛时仅报告证据。

|模式|成功回合|平均查询 ms|平均策略总耗时 ms|平均回合墙钟 s|查询/策略/墙钟加速比|
|---|---:|---:|---:|---:|---|
|baseline|1/1|137.62|2889.96|6.601|1.000× / 1.000× / 1.000×|
|vla_pruner|1/1|128.56|2956.85|7.213|1.070× / 0.977× / 0.915×|
|fastv_scoring|1/1|105.57|1900.34|5.111|1.304× / 1.521× / 1.292×|

Model-query wrapper, excluding simulator steps; per-episode sum uses all queries

选择器各候选的排除原因：
- baseline: 未排除；未给门槛时不作达标判断
- fastv_scoring: 未排除；未给门槛时不作达标判断
- vla_pruner: 未排除；未给门槛时不作达标判断

原始报告：/home/wxy/Rui_work/live-evaluator-20261113/oft-003/measurement/report.json
SHA256：52a06f1259c73d57488b3f64af572f637dceb6973624ce6b635bd481822898fb
