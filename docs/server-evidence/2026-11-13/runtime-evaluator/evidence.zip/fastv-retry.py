import json,os,subprocess,time
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');os.chdir(root)
(root/'fastv-retry.pid').write_text(str(os.getpid()))
while not (root/'light-retry-process.json').exists():time.sleep(3)
for profile in ['fastv_oft_spatial','fastv_openvla_spatial']:
 p=json.loads((root/(profile+'.json')).read_text());p['python']='/data2/wxy/VLA-Adapter/conda_envs/openvla-fastv/bin/python';p['cublas_dir']='/data4/wxy/midterm-oft-first-use/runtime-cublas/nvidia/cublas/lib'
 name=profile+'-retry.json';(root/name).write_text(json.dumps(p))
 env=os.environ.copy();env.update(PYTHONPATH='/data4/wxy/midterm-oft-first-use/src/LIBERO',LIBERO_CONFIG_PATH='/data4/wxy/midterm-oft-first-use/libero-config',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TF_NUM_INTEROP_THREADS='2',TF_NUM_INTRAOP_THREADS='4')
 cmd=[p['python'],'-u','-B','-m','core','select','--project',name,'--output',profile+'-002']
 if profile=='fastv_oft_spatial':cmd+=['--tasks','0']
 (root/(profile+'-retry-command.json')).write_text(json.dumps(cmd))
 with (root/(profile+'-retry.log')).open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (root/(profile+'-retry-process.json')).write_text(json.dumps({'exit_code':result.returncode}))
