import json,os,subprocess,time,shutil
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');os.chdir(root)
(root/'light-final.pid').write_text(str(os.getpid()))
while not (root/'fastv_oft_spatial-compat-process.json').exists():time.sleep(3)
deps=root/'deps';site=Path('/data4/wxy/midterm-oft-first-use/env/lib/python3.10/site-packages')
for pattern in ['cycler*','kiwisolver*','dateutil*','python_dateutil*','six.py','six-*.dist-info']:
 for src in site.glob(pattern):
  dst=deps/src.name
  if src.is_dir():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__'))
  else:shutil.copy2(src,dst)
p=json.loads((root/'lightvla_spatial-compat.json').read_text())
env=os.environ.copy();env.update(PYTHONPATH=str(deps)+':/data4/wxy/midterm-oft-first-use/src/LIBERO',LIBERO_CONFIG_PATH='/data4/wxy/midterm-oft-first-use/libero-config',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TF_NUM_INTEROP_THREADS='2',TF_NUM_INTRAOP_THREADS='4')
cmd=[p['python'],'-u','-B','-m','core','select','--project','lightvla_spatial-compat.json','--tasks','0','--output','lightvla_spatial-004']
(root/'light-final-command.json').write_text(json.dumps(cmd))
result=subprocess.run(cmd,env=env)
(root/'light-final-process.json').write_text(json.dumps({'exit_code':result.returncode}))
