#!/bin/bash
set -eu
cd /home/wxy/Rui_work/live-evaluator-20261113
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export PYTHONPATH=/home/wxy/Rui_work/scoring-1110/deps
export LIBERO_CONFIG_PATH=/home/wxy/daisy_work/openvla-fastv-code/.libero-config
unset LD_PRELOAD LD_LIBRARY_PATH
exec /data2/wxy/VLA-Adapter/conda_envs/openvla-oft/bin/python -u -B -m core select --project project.json --tasks 0 --trials-per-task 1 --output oft-001
