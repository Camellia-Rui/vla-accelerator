import json,os,subprocess,time,shutil
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');os.chdir(root)
(root/'compat-retry.pid').write_text(str(os.getpid()))
while not (root/'fastv_openvla_spatial-retry-process.json').exists():time.sleep(3)
deps=root/'deps';deps.mkdir(exist_ok=False)
site=Path('/data4/wxy/midterm-oft-first-use/env/lib/python3.10/site-packages')
for pattern in ['pyparsing*','diffusers*']:
 for src in site.glob(pattern):shutil.copytree(src,deps/src.name,ignore=shutil.ignore_patterns('__pycache__'))
for profile in ['lightvla_spatial','fastv_oft_spatial']:
 p=json.loads((root/(profile+'.json')).read_text())
 if profile=='fastv_oft_spatial':
  p['python']='/data2/wxy/VLA-Adapter/conda_envs/openvla-fastv/bin/python';p['cublas_dir']='/data4/wxy/midterm-oft-first-use/runtime-cublas/nvidia/cublas/lib'
 name=profile+'-compat.json';(root/name).write_text(json.dumps(p))
 env=os.environ.copy();env.update(PYTHONPATH=str(deps)+':/data4/wxy/midterm-oft-first-use/src/LIBERO',LIBERO_CONFIG_PATH='/data4/wxy/midterm-oft-first-use/libero-config',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TF_NUM_INTEROP_THREADS='2',TF_NUM_INTRAOP_THREADS='4')
 cmd=[p['python'],'-u','-B','-m','core','select','--project',name,'--tasks','0','--output',profile+'-003']
 (root/(profile+'-compat-command.json')).write_text(json.dumps(cmd))
 with (root/(profile+'-compat.log')).open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (root/(profile+'-compat-process.json')).write_text(json.dumps({'exit_code':result.returncode}))
