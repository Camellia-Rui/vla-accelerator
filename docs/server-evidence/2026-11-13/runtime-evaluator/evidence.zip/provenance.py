import json,subprocess,hashlib
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');out={}
for config in ['project-003.json','specprune_object.json','lightvla_spatial-compat.json','fastv_oft_spatial-compat.json','fastv_openvla_spatial-retry.json']:
 p=root/config
 if not p.exists():continue
 data=json.loads(p.read_text());workspace=Path(data['workspace']);checkpoint=Path(data['checkpoint'])
 record={'project':data,'source_revision':subprocess.run(['git','-C',str(workspace),'rev-parse','HEAD'],capture_output=True,text=True).stdout.strip(),
 'source_dirty':subprocess.run(['git','-C',str(workspace),'status','--porcelain'],capture_output=True,text=True).stdout,
 'checkpoint_metadata_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in checkpoint.iterdir() if f.is_file() and f.suffix in ['.json','.py']},
 'checkpoint_weight_inventory':{f.name:{'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns} for f in checkpoint.iterdir() if f.is_file() and f.suffix in ['.bin','.safetensors','.pt']}}
 out[config]=record
(root/'resource-provenance.json').write_text(json.dumps(out,indent=2))
