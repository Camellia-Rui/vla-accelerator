# 自动评估报告

执行状态：FINISHED
样本门槛：NOT_SPECIFIED
选择：未选择

样本满足门槛不代表统计无损或部署验收通过。未提供门槛时仅报告证据。

|模式|成功回合|平均查询 ms|平均策略总耗时 ms|平均回合墙钟 s|查询/策略/墙钟加速比|
|---|---:|---:|---:|---:|---|
|fastv|1/1|193.64|1936.36|9.296|1.114× / 1.114× / 1.802×|
|baseline|1/1|215.77|2157.73|16.753|1.000× / 1.000× / 1.000×|

FastV query includes its preprocessing; wall timing scope is backend-specific (see method guide)

选择器各候选的排除原因：
- baseline: 未排除；未给门槛时不作达标判断
- fastv: 未排除；未给门槛时不作达标判断

原始报告：/home/wxy/Rui_work/live-evaluator-20261113/fastv_oft_spatial-003/measurement/report.json
SHA256：8a560bc0e2dbed0e595b0cb6a2fee7f3518af5d278aa2b2b6b3073c20924d4e8
