import json,os,subprocess,time
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');os.chdir(root)
(root/'light-retry.pid').write_text(str(os.getpid()))
while not (root/'fastv_openvla_spatial-process.json').exists():time.sleep(3)
p=json.loads((root/'lightvla_spatial.json').read_text());p['python']='/data4/wxy/midterm-oft-first-use/env/bin/python';(root/'light-retry.json').write_text(json.dumps(p))
env=os.environ.copy();env.update(PYTHONPATH='/data4/wxy/midterm-oft-first-use/src/LIBERO',LIBERO_CONFIG_PATH='/data4/wxy/midterm-oft-first-use/libero-config',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TF_NUM_INTEROP_THREADS='2',TF_NUM_INTRAOP_THREADS='4')
cmd=[p['python'],'-u','-B','-m','core','select','--project','light-retry.json','--tasks','0','--output','lightvla_spatial-002']
(root/'light-retry-command.json').write_text(json.dumps(cmd))
result=subprocess.run(cmd,env=env)
(root/'light-retry-process.json').write_text(json.dumps({'exit_code':result.returncode}))
