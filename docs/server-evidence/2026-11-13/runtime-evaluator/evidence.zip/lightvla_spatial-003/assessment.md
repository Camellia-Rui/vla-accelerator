# 自动评估报告

执行状态：FAILED

质量结论：INCONCLUSIVE

本次运行或证据检查未完成，不产生达标结论。

错误：Command '['/home/wxy/miniconda3/envs/daisy_openvla/bin/python', '-B', '-m', 'core', 'evaluate', '--method', 'lightvla', '--workspace', '/home/wxy/daisy_work/lightvla_clean', '--checkpoint', '/home/wxy/daisy_work/lightvla_clean/checkpoints/lightvla_spatial_official', '--gpu', '1', '--output', '/home/wxy/Rui_work/live-evaluator-20261113/lightvla_spatial-003/measurement', '--closed-loop', '--tasks', '0', '--trials', '0']' returned non-zero exit status 2.

原始日志与已有记录：/home/wxy/Rui_work/live-evaluator-20261113/lightvla_spatial-003/measurement
