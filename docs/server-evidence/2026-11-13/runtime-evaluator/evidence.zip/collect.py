import json,hashlib,zipfile
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113')
blocked={'cache','deps','checkpoint','rollouts','__pycache__'}
files=[p for p in root.rglob('*') if p.is_file() and not p.is_symlink() and not blocked.intersection(p.relative_to(root).parts) and p.suffix in {'.json','.md','.log','.csv','.jsonl','.py','.sh','.npy','.npz','.txt'}]
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(root/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(root/name,name)
 z.write(root/'evidence-manifest.json','evidence-manifest.json')
print(json.dumps({'files':len(manifest),'bytes':(root/'evidence.zip').stat().st_size,'sha256':hashlib.sha256((root/'evidence.zip').read_bytes()).hexdigest()}))
