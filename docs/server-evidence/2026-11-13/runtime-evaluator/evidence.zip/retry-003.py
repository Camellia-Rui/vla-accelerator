import json,os,subprocess
from pathlib import Path
root=Path('/home/wxy/Rui_work/live-evaluator-20261113');os.chdir(root)
p=json.loads((root/'project.json').read_text());p['python']='/data4/wxy/midterm-oft-first-use/env/bin/python';(root/'project-003.json').write_text(json.dumps(p))
env=os.environ.copy();env.update(PYTHONPATH='/data4/wxy/midterm-oft-first-use/src/LIBERO',LIBERO_CONFIG_PATH='/data4/wxy/midterm-oft-first-use/libero-config',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TF_NUM_INTEROP_THREADS='2',TF_NUM_INTRAOP_THREADS='4')
cmd=[p['python'],'-u','-B','-m','core','select','--project','project-003.json','--tasks','0','--output','oft-003']
(root/'command-003.json').write_text(json.dumps(cmd))
result=subprocess.run(cmd,env=env)
(root/'process-003.json').write_text(json.dumps({'exit_code':result.returncode}))
