"""Verify evidence-backed page links, PNG payloads and JS task switching (no browser rendering)."""
import base64
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        self.links.extend(value for key, value in attrs if key == "href")


def main():
    path = ROOT / "SHOWCASE.html"
    source = path.read_text(encoding="utf-8")
    parser = Links()
    parser.feed(source)
    data = json.loads(source.split("const data=", 1)[1].split(";\nconst el=", 1)[0])
    for task in data:
        parser.links.extend((task["report"], task["raw"]))
        for image in task["images"]:
            assert base64.b64decode(image.split(",", 1)[1]).startswith(b"\x89PNG\r\n\x1a\n")
    for link in parser.links:
        if ":" not in link and not link.startswith("#"):
            assert (ROOT / link).is_file(), link
    assert len(data) == 3 and sum(t["pairs"] for t in data) == 18
    node = shutil.which("node")
    if not node:
        raise RuntimeError("Node is required only for page-script verification")
    program = r'''
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const source=fs.readFileSync(process.argv[1],'utf8');
const script=source.match(/<script>([\s\S]*?)<\/script>/)[1];
function element(){return {children:[],style:{},attributes:{},listeners:{},textContent:'',
 setAttribute(k,v){this.attributes[k]=v},addEventListener(k,v){this.listeners[k]=v},appendChild(c){this.children.push(c)}}}
const nodes={}; const document={getElementById(id){return nodes[id]??(nodes[id]=element())},createElement(){return element()}};
const context=vm.createContext({document}); vm.runInContext(script,context);
assert.equal(nodes.tabs.children.length,3);
for(let i=0;i<3;i++){nodes.tabs.children[i].listeners.click();
 assert(nodes['task-title'].textContent.includes('任务 '+i));
 assert.equal(nodes.tabs.children[i].attributes['aria-selected'],'true');
 assert(nodes.primary.src.startsWith('data:image/png;base64,'));
 assert(nodes['report-link'].href.endsWith('/report.json'));
 assert.equal(nodes['tokens-before'].textContent,512);assert.equal(nodes['tokens-after'].textContent,256);}
console.log('Page task switching: PASS (DOM stub, not visual rendering)');
'''
    subprocess.run([node, "-e", program, str(path)], check=True)
    print("Page links, image payloads and evidence counts: PASS")


if __name__ == "__main__":
    main()
