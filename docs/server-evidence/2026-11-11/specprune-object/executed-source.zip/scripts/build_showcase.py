"""Generate an offline, evidence-backed demo page; never invent missing results."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import zlib

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "docs/server-evidence/2026-11-02"


def png_data(array):
    if str(array.dtype) != "uint8" or array.ndim != 3 or array.shape[2] != 3:
        raise ValueError("Expected original uint8 RGB image")
    height, width, _ = array.shape
    def chunk(kind, payload):
        return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xffffffff)
    raw = b"".join(b"\0" + row.tobytes() for row in array)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    return "data:image/png;base64," + base64.b64encode(png).decode()


def load_tasks():
    import numpy as np
    locations = [(EVIDENCE / "verified-pruner-pair/capture-001", EVIDENCE / "verified-pruner-pair/pruner-pair-001")]
    locations += [(EVIDENCE / f"multitask-smoke/capture-task{i}-trial0", EVIDENCE / f"multitask-smoke/pruner-task{i}-trial0") for i in (1, 2)]
    tasks = []
    for capture_dir, pair_dir in locations:
        capture = json.loads((capture_dir / "report.json").read_text(encoding="utf-8"))
        report = json.loads((pair_dir / "report.json").read_text(encoding="utf-8"))
        raw = capture_dir / "observation.npz"
        sha = hashlib.sha256(raw.read_bytes()).hexdigest()
        if sha != capture["observation_sha256"] or sha != report["observation_sha256"]:
            raise ValueError("Observation hash mismatch")
        if not capture["passed"] or not report["passed"]:
            raise ValueError("Do not present a failed experiment as passed")
        records = [json.loads(line) for line in (pair_dir / "records.jsonl").read_text().splitlines()]
        if records != report["records"]:
            raise ValueError("Raw records differ from report")
        timings = {mode: [r["query_ms"] for r in records if r["mode"] == mode] for mode in ("disabled", "enabled")}
        if not timings["disabled"] or len(timings["disabled"]) != len(timings["enabled"]):
            raise ValueError("Unpaired timing samples")
        baseline = float(np.median(timings["disabled"]))
        accelerated = float(np.median(timings["enabled"]))
        stats = report["pruning_stats"]
        with np.load(raw, allow_pickle=False) as data:
            images = [png_data(data[k]) for k in ("full_image", "wrist_image")]
        tasks.append(dict(task=capture["task_id"], description=capture["task_description"], images=images,
            pairs=len(timings["disabled"]), baseline=baseline, accelerated=accelerated, ratio=baseline/accelerated,
            mae=report["diagnostic_action_difference"]["mae"], maximum=report["diagnostic_action_difference"]["max_abs"],
            gripper=report["diagnostic_action_difference"]["raw_gripper_sign_agreement"],
            before=stats["visual_tokens_before"], after=stats["visual_tokens_kept"],
            seqBefore=stats["sequence_tokens_before"], seqAfter=stats["sequence_tokens_after"],
            control=report["native_vs_disabled"]["max_abs"], restored=report["native_vs_detached"]["max_abs"],
            report=(pair_dir/"report.json").relative_to(ROOT).as_posix(),
            raw=(pair_dir/"records.jsonl").relative_to(ROOT).as_posix(), hash=sha))
    return tasks


def main():
    tasks = load_tasks()
    template = (ROOT / "docs/showcase-template.html").read_text(encoding="utf-8")
    page = template.replace("__EVIDENCE_DATA__", json.dumps(tasks, ensure_ascii=False).replace("<", "\\u003c"))
    (ROOT / "SHOWCASE.html").write_text(page, encoding="utf-8")
    summary = [{k: v for k, v in task.items() if k != "images"} for task in tasks]
    (ROOT / "docs/showcase-results.json").write_text(json.dumps({"scope": "three fixed initial observations, not closed-loop success", "tasks": summary}, ensure_ascii=False, indent=2)+"\n",encoding="utf-8")
    print("SHOWCASE built from verified raw records:", len(tasks), "inputs")


if __name__ == "__main__":
    main()
